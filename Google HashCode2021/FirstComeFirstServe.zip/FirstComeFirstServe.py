# myFile = open("in/a_example.in")
# myFile = open("in/b_little_bit_of_everything.in")
# myFile = open("in/c_many_ingredients.in")
# myFile = open("in/d_many_pizzas.in")
# myFile = open("in/e_many_teams.in")

Pizz,Te2,Te3,Te4  = map(int,myFile.readline().split())
# print(Pizz,Te2,Te3,Te4)

# myOfile = open("out/a.out","w")
# myOfile = open("out/b.out","w")
# myOfile = open("out/c.out","w")
# myOfile = open("out/d.out","w")
# myOfile = open("out/e.out","w")

serv = 0
total = Te2+Te3+Te4

for i in range(total):
    if i < Te2 and serv+1 < Pizz:
        print(2,serv,serv+1)
        myOfile.write(str(2)+" "+str(serv)+" "+str(serv+1)+"\n")
        serv += 2

    elif Te2 <= i < Te2+Te3 and serv+2 < Pizz:
        print(3,serv,serv+1,serv+2)
        myOfile.write(str(3)+" "+str(serv)+" "+str(serv+1)+" "+str(serv+2)+"\n")
        serv += 3
    
    elif Te2+Te3 <= i < Te2+Te3+Te4 and serv+3 < Pizz:
        print(4,serv,serv+1,serv+2,serv+3)
        myOfile.write(str(4)+" "+str(serv)+" "+str(serv+1)+" "+str(serv+2)+" "+str(serv+3)+"\n")
        serv += 4
    
    if serv >= Pizz-1:
        break